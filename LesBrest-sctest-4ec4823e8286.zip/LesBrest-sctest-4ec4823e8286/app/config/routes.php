<?php

return [
  '' => [
    'controller' => 'main',
    'action' => 'index',
  ],
  'products/delete' => [
    'controller' => 'main',
    'action' => 'delete',
  ],
  'product/add' => [
    'controller' => 'product',
    'action' => 'add',
  ],
  'product/save' => [
    'controller' => 'product',
    'action' => 'save',
  ],
 
];