<?php
  return [
    'host' => 'localhost',
    'name' => 'mvcdb',
    'user' => 'alex_les',
    'password' => '4XHlKzFHsFtlVFhe',
    
  ];